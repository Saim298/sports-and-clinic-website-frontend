import React from 'react'

const AdminPanel = () => {
  return (
    <div>AdminPanel</div>
  )
}

export default AdminPanel