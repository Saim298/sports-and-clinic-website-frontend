import React from 'react'
import Subscribe from '../component/Subscribe'

const SubscribePage = () => {
  return (
    <div><Subscribe/></div>
  )
}

export default SubscribePage