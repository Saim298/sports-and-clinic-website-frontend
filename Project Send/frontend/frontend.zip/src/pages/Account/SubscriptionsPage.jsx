import React from 'react'
import Subscriptions from '../../component/Account/Subscriptions'

const SubscriptionsPage = () => {
  return (
    <div><Subscriptions/></div>
  )
}

export default SubscriptionsPage