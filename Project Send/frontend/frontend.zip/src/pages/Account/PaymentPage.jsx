import React from 'react'
import Payment from '../../component/Account/Payment'

const PaymentPage = () => {
  return (
    <div><Payment/></div>
  )
}

export default PaymentPage