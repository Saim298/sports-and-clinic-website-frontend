import React from 'react'
import EventsListing from '../../../component/AdminPanel/Events/EventsListing'

const EventsListingPage = () => {
  return (
    <div><EventsListing/></div>
  )
}

export default EventsListingPage