import React from 'react'
import EventRegistrant from '../../../component/AdminPanel/Events/EventRegistrant'

const EventRegistrantPage = () => {
  return (
    <div><EventRegistrant/></div>
  )
}

export default EventRegistrantPage