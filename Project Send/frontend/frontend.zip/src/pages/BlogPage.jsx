import React from 'react'
import Blog from '../component/Blog'

const BlogPage = () => {
  return (
    <div><Blog/></div>
  )
}

export default BlogPage