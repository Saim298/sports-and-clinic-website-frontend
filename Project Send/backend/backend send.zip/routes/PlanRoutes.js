const express = require('express');
const router = express.Router();
const planController = require('../controllers/PlanController'); // Assuming the controller file is named planController.js

// Route to create a new plan
router.post('/plans', planController.createPlan);

// Route to get all plans
router.get('/plans', planController.getAllPlans);

// Route to get a specific plan by ID
router.get('/plans/:id', planController.getPlanById);

// Route to update a specific plan by ID
router.put('/plans/:id', planController.updatePlan);

// Route to delete a specific plan by ID
router.delete('/plans/:id', planController.deletePlan);

module.exports = router;
