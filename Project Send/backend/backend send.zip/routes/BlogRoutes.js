const express = require("express");
const router = express.Router();
const multer = require("multer");
const BlogController = require("../controllers/BlogController");

// Multer setup
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Route for creating a blog
router.post("/blogs", upload.single("blogImage"), BlogController.createBlog);

router.get("/blogs", BlogController.getBlogs);
router.get("/blogs/:id", BlogController.getBlogById);
router.put("/blogs/:id", upload.single("blogImage"), BlogController.updateBlog);
router.delete("/blogs/:id", BlogController.deleteBlog);

// Route to increment views
router.put("/blogs/:blogId/increment-view", BlogController.incrementView);

// Route to add a comment to a blog
router.post("/blogs/:blogId/comments", BlogController.addComment);

// Route to reply to a specific comment
router.post(
  "/blogs/:blogId/comments/:commentId/reply",
  BlogController.replyToComment
);

module.exports = router;
