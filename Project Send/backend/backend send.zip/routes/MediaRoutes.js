const express = require("express");
const router = express.Router();
const mediaController = require("../controllers/MediaController");
const multer = require("multer");
const storage = multer.memoryStorage(); // Use memory storage to handle file uploads
const upload = multer({ storage });

router.post("/media", upload.single("main_page_image"), mediaController.createMedia);

// Update media
router.put("/media/:id", upload.single("main_page_image"), mediaController.updateMedia);

// Get all media
router.get("/media", mediaController.getAllMedia);

// Get media by ID
router.get("/media/:id", mediaController.getMediaById);

// Delete media
router.delete("/media/:id", mediaController.deleteMedia);

module.exports = router;
