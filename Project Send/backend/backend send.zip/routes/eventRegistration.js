const express = require("express");
const {
  registerForEvent,
  confirmPayment,
  getUserOrders,
} = require("../controllers/EventRegistrationController");
const { isAuthenticated } = require("../middleware/authMiddleware");

const router = express.Router();

// Route for registering for an event and initiating payment
router.post("/register", registerForEvent);

// Route for confirming payment (Stripe)
router.post("/confirm-payment", confirmPayment);


// Route to get orders by user
router.get("/orders/:userId", getUserOrders);

module.exports = router;
