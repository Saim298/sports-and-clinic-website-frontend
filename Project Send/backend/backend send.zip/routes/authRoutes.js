const express = require("express");
const User = require("../models/User");
const OrderModel = require("../models/OrderModel");
const RegistrationModel = require("../models/RegistrationModel");
const router = express.Router();
const bcrypt = require("bcrypt"); // For password hashing and comparison

// User Registration
router.post("/register", async (req, res) => {
  try {
    const { firstName, lastName, email, contactNumber, address, password } =
      req.body;

    const user = new User({
      firstName,
      lastName,
      email,
      contactNumber,
      address,
      password,
    });

    await user.save();

    // Send back the user ID along with the success message
    res.status(201).json({
      message: "User registered successfully.",
      userId: user._id,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// User Login
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(400).json({ error: "Invalid credentials." });
    }

    const isMatch = await user.comparePassword(password);

    if (!isMatch) {
      return res.status(400).json({ error: "Invalid credentials." });
    }

    res.status(200).json({
      message: "User logged in successfully.",
      userId: user._id, // Include user ID in the response
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get User by ID including Orders and Registrations
router.get("/user/:id", async (req, res) => {
  try {
    const userId = req.params.id;

    // Find the user by ID, exclude the password field, and populate orders and registrations
    const user = await User.findById(userId)
      .select("-password") // Exclude the password field
      .populate({
        path: "orders",
        model: OrderModel,
      })
      .populate({
        path: "registrations",
        model: RegistrationModel,
      });

    if (!user) {
      return res.status(404).json({ error: "User not found." });
    }

    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update User Details
router.put("/user/:id", async (req, res) => {
  try {
    const userId = req.params.id;
    const { firstName, lastName, email, contactNumber } = req.body;

    const user = await User.findByIdAndUpdate(
      userId,
      { firstName, lastName, email, contactNumber },
      { new: true } // Return the updated document
    ).select("-password"); // Exclude the password field

    if (!user) {
      return res.status(404).json({ error: "User not found." });
    }

    res.status(200).json({
      message: "User details updated successfully.",
      user,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Change Password
router.put("/user/password/:id", async (req, res) => {
  try {
    const userId = req.params.id;
    const { oldPassword, newPassword } = req.body;

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ error: "User not found." });
    }

    // Check if old password is correct
    const isMatch = await user.comparePassword(oldPassword);

    if (!isMatch) {
      return res.status(400).json({ error: "Old password is incorrect." });
    }

    // Hash the new password and save it
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(newPassword, salt);

    user.password = hashedPassword;
    await user.save();

    res.status(200).json({ message: "Password updated successfully." });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// Get All Users with Google and Facebook ID Flags
router.get("/users", async (req, res) => {
  try {
    const users = await User.find().select("-password"); // Exclude the password field

    // Add flags for Google and Facebook IDs
    const usersWithFlags = users.map(user => ({
      ...user.toObject(),
      google: !!user.googleId, // true if googleId exists, otherwise false
      facebook: !!user.facebookId, // true if facebookId exists, otherwise false
    }));

    res.status(200).json(usersWithFlags);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
