const express = require("express");
const router = express.Router();
const eventController = require("../controllers/EventController");
const upload = require("../utils/multer");

// Event Routes
router.post(
  "/events",
  upload.fields([
    { name: "images", maxCount: 4 },
    { name: "videos", maxCount: 4 },
  ]),
  eventController.createEvent
);

router.get("/events", eventController.getAllEvents);
router.get("/event/plan/:id", eventController.getEventPlanById);
router.get("/events/:id", eventController.getEventById);
router.put("/events/:id", eventController.updateEvent);
router.delete("/events/:id", eventController.deleteEvent);
router.get("/latest-events", eventController.getLatestEvents);
// Route to bookmark an event
router.post("/bookmark", eventController.bookmarkEvent);

// Route to get bookmarked events for a user
router.get("/bookmarked-events/:userId", eventController.getBookmarkedEvents);

// Add a review to an event
router.post("/events/review", eventController.addEventReview);
// Route to get all registered events
router.get('/events/registered', eventController.getAllRegisteredEvents);


module.exports = router;
