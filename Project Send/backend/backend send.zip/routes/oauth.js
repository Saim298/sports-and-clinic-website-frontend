const express = require('express');
const passport = require('passport');

const router = express.Router();

// Google Authentication Route
router.get('/google', passport.authenticate('google', {
  scope: ['profile', 'email']
}));

// Google Authentication Callback Route
router.get(
  '/google/callback',
  passport.authenticate('google', { failureRedirect: '/login' }),
  (req, res) => {
     // Get the user ID from req.user
     const userId = req.user.id;

     // Redirect to frontend with user ID as a query parameter
     res.redirect(`http://localhost:3000/account/overview?userId=${userId}`);
  }
);

// Facebook Authentication Route
router.get('/facebook', passport.authenticate('facebook', {
  scope: ['email']
}));

// Facebook Authentication Callback Route
router.get(
  '/facebook/callback',
  passport.authenticate('facebook', { failureRedirect: '/login' }),
  (req, res) => {
     // Get the user ID from req.user
     const userId = req.user.id;

     // Redirect to frontend with user ID as a query parameter
     res.redirect(`http://localhost:3000/account/overview?userId=${userId}`);
  }
);

// Logout Route
router.get('/logout', (req, res) => {
  req.logout((err) => {
    if (err) {
      return next(err);
    }
    res.redirect('/'); // Redirect to homepage after logout
  });
});

module.exports = router;
