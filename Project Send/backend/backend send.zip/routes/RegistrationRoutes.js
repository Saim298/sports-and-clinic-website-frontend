const express = require('express');
const router = express.Router();
const registrationController = require('../controllers/RegistrationController');

// Registration Routes
router.post('/registrations', registrationController.registerForEvent);
router.get('/registrations/user/:userId', registrationController.getUserRegistrations);
router.get('/registrations/event/:eventId', registrationController.getEventRegistrations);

// Route to get registrants for a specific event
router.get("/events/registrants/:id", registrationController.getRegistrantsByEventId);


module.exports = router;
