// routes/contactRoutes.js
const express = require('express');
const router = express.Router();
const { createContact, getContacts } = require('../controllers/contactController');

// POST route to submit contact form
router.post('/contact', createContact);

// GET route to retrieve contact information (if needed for admin purposes)
router.get('/contacts', getContacts);

module.exports = router;
