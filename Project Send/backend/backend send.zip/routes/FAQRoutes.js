const express = require("express");
const router = express.Router();
const FAQ = require("../models/FAQModel"); // Import the FAQ model

// Add a new FAQ
router.post("/faq", async (req, res) => {
  try {
    const { question, answer } = req.body;

    const newFAQ = new FAQ({
      question,
      answer,
    });

    await newFAQ.save();

    res.status(201).json({ message: "FAQ added successfully", faq: newFAQ });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

// Get all FAQs
router.get("/faqs", async (req, res) => {
  try {
    const faqs = await FAQ.find();
    res.status(200).json(faqs);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

// Update an FAQ
router.put("/faq/:id", async (req, res) => {
  try {
    const { question, answer } = req.body;
    const faqId = req.params.id;

    const updatedFAQ = await FAQ.findByIdAndUpdate(
      faqId,
      { question, answer, updatedAt: Date.now() },
      { new: true }
    );

    if (!updatedFAQ) {
      return res.status(404).json({ message: "FAQ not found" });
    }

    res
      .status(200)
      .json({ message: "FAQ updated successfully", faq: updatedFAQ });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

// Delete an FAQ
router.delete("/faq/:id", async (req, res) => {
  try {
    const faqId = req.params.id;

    const deletedFAQ = await FAQ.findByIdAndDelete(faqId);

    if (!deletedFAQ) {
      return res.status(404).json({ message: "FAQ not found" });
    }

    res.status(200).json({ message: "FAQ deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
