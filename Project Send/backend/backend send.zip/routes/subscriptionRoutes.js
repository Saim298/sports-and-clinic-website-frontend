const express = require("express");
const router = express.Router();
const subscriptionController = require("../controllers/subscriptionController");

// Route to subscribe to a plan
router.post("/subscribe", subscriptionController.subscribeToPlan);

// Route to check subscription status
router.post("/check-subscription", subscriptionController.checkUserSubscription);

// Route to update subscription status
router.put("/update-subscription-status", subscriptionController.updateSubscriptionStatus);

// Route to generate invoices for all subscriptions of a user
router.post("/generate-invoices", subscriptionController.generateInvoices);

module.exports = router;
