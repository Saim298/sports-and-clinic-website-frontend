const express = require("express");
const router = express.Router();
const invoiceController = require("../controllers/invoiceController");
const multer = require("multer");
const upload = multer(); // Initialize multer for file uploads

// Image upload route
router.post("/upload-image", upload.single("image"), invoiceController.uploadImage);

// Route to create a new invoice
router.post("/create", invoiceController.createInvoice);
router.get("/save/:userId", invoiceController.saveInvoice);

// Route to get the active invoice
router.get("/active", invoiceController.getActiveInvoice);

// Route to update an existing invoice
router.put("/update", invoiceController.updateInvoice);

module.exports = router;
