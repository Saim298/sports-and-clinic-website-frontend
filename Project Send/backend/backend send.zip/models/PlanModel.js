const mongoose = require("mongoose");

// Define the Plan schema
const planSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
    },
    price: {
      monthly: {
        type: Number,
        required: true,
        min: 0,
      },
      yearly: {
        type: Number,
        required: true,
        min: 0,
      },
    },
    duration: {
      type: String,
      enum: ["monthly", "yearly"], // Restrict to 'monthly' or 'yearly'
      required: true,
    },
    coupons: {
      type: String,
      trim: true,
    },
    discount: {
      type: Number,
      min: 0,
      max: 100,
    },
    subHeading: {
      type: String,
      trim: true,
    },
    points: {
      type: [String],
      default: [],
    },
    enhancedFeatures: {
      type: Boolean,
      default: false,
    },
    exportBookmarks: {
      type: Boolean,
      default: false,
    },
    personalizedNotifications: {
      type: Boolean,
      default: false,
    },
    exclusiveContent: {
      type: Boolean,
      default: false,
    },
    accessSchoolInfo: {
      type: Boolean,
      default: false,
    },
    accessCampInfo: {
      type: Boolean,
      default: false,
    },
    canLeaveReviews: {
      type: Boolean,
      default: false,
    },
    renewsMonthly: {
      type: Boolean,
      default: false,
    },
    adFreeViewing: {
      type: Boolean,
      default: false,
    },
    support24_7: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// Automatically update the points array based on selected features
planSchema.pre("save", function (next) {
  const plan = this;

  plan.points = [];

  if (plan.enhancedFeatures) plan.points.push("Enhanced features");
  if (plan.exportBookmarks)
    plan.points.push("Export bookmarks into printable format");
  if (plan.personalizedNotifications)
    plan.points.push("Personalized notifications");
  if (plan.exclusiveContent) plan.points.push("Exclusive content");
  if (plan.accessSchoolInfo) plan.points.push("Access to school information");
  if (plan.accessCampInfo) plan.points.push("Access to all camp information");
  if (plan.canLeaveReviews) plan.points.push("Can leave reviews for camps");
  if (plan.renewsMonthly) plan.points.push("Renews monthly");
  if (plan.adFreeViewing) plan.points.push("Ad-free Viewing");
  if (plan.support24_7) plan.points.push("24/7 Support");

  next();
});

// Create the Plan model
const Plan = mongoose.model("Plan", planSchema);

module.exports = Plan;
