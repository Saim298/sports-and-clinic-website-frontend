const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
  },
  description: {
    type: String,
    required: true,
  },
  date: {
    type: Date,
    required: true,
  },
  time: {
    type: String,
    required: true,
  },
  endDate: { // Added end date field
    type: Date,
  },
  location: {
    type: {
      type: String,
      default: "Point",
    },
    coordinates: {
      type: [Number],
    },
    address: {
      type: String,
    },
  },
  briefCampIntro: {
    type: String,
    required: true,
  },
  athleticsInfo: {
    governingBody: {
      type: String,
      required: true,
    },
    division: {
      type: String,
      required: true,
    },
    conference: {
      type: String,
    },
    campWebsite: {
      type: String,
    },
    recruitingQuestionnaire: {
      type: String,
    },
  },
  campWebsiteLink: {
    type: String,
  },
  socialNetworks: {
    instagram: { type: String },
    x: { type: String },
    facebook: { type: String },
    threads: { type: String },
  },
  tags: [
    {
      type: String,
    },
  ],
  category: {
    type: String,  // Single category as a string
  },
  coachProfiles: [
    {
      name: { type: String, required: true },
      bio: { type: String, required: true },
      experience: { type: String, required: true },
    },
  ],
  reviews: [
    {
      user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      review: { type: String },
      rating: { type: Number, min: 1, max: 5 },
    },
  ],
  ageGroups: [
    {
      ageGroup: { type: String, required: true },
      maxParticipants: { type: Number, required: true },
    },
  ],
  media: {
    images: [{ type: String }],
    videos: [{ type: String }],
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
  discount: {
    type: Number,
    min: 0,
    max: 100,
    default: 0,
  },
  promoCodes: [
    {
      code: String,
      discount: {
        type: Number,
        min: 0,
        max: 100,
      },
      validUntil: Date,
    },
  ],
  recurring: {
    isRecurring: { type: Boolean, default: false },
    recurrenceRule: { type: String },
    endDate: { type: Date },
  },
  isActive: {
    type: Boolean,
    default: function () {
      return !this.recurring.endDate || new Date() <= this.recurring.endDate;
    },
  },
});

eventSchema.index({ location: "2dsphere" });

module.exports = mongoose.model("Event", eventSchema);
