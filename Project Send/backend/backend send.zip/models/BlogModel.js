const mongoose = require('mongoose');

// Comment Schema
const commentSchema = new mongoose.Schema({
  userName: {
    type: String,
    required: true,
  },
  content: {
    type: String,
    required: true,
  },
  replies: [
    {
      userName: {
        type: String,
        required: true,
      },
      content: {
        type: String,
        required: true,
      },
      createdAt: {
        type: Date,
        default: Date.now,
      },
    },
  ],
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// Blog Schema
const blogSchema = new mongoose.Schema({
  blogName: {
    type: String,
    required: true,
    trim: true,
  },
  blogImage: {
    type: String, // URL to the image
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  keywords: {
    type: [String], // Array of keywords
    required: true,
  },
  metaTags: {
    type: [String], // Array of meta tags
  },
  comments: [commentSchema], // Embedded comments
  views: {
    type: Number,
    default: 0,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// Update the updatedAt field before saving
blogSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Blog', blogSchema);
