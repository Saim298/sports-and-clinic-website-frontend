const mongoose = require("mongoose");

const mediaSchema = new mongoose.Schema({
  main_page_main_text: {
    type: String,
    required: true,
  },
  main_page_para_text: {
    type: String,
    required: true,
  },
  footer_text: {
    type: String,
    required: true,
  },
  main_page_image: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

mediaSchema.pre("save", function (next) {
  this.updatedAt = Date.now();
  next();
});

const Media = mongoose.model("Media", mediaSchema);

module.exports = Media;
