const express = require("express");
const connectDB = require("./config/db");
const passport = require("passport");
const cors = require("cors");
const session = require("express-session");
require("dotenv").config(); // Load environment variables

const app = express();

// Connect to MongoDB
connectDB();

// Session middleware
app.use(
  session({
    secret: process.env.JWT_SECRET, // replace with your own secret key
    resave: false, // don't save session if unmodified
    saveUninitialized: true, // don't create session until something stored
    cookie: { secure: false }, // set to true if using https
  })
);
// Routes
// Middleware
app.use(express.json());
app.use(passport.initialize());
app.use(cors());
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

// Passport middleware
app.use(passport.session());

require("./middleware/passport"); // Load Passport.js strategies

app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/auth", require("./routes/oauth"));
app.use(
  "/api/event/registration/payment",
  require("./routes/eventRegistration")
);
app.use("/api/event/registration/creation", require("./routes/EventRoutes"));
app.use(
  "/api/event/registration/event",
  require("./routes/RegistrationRoutes")
);
// Admin Route
app.use("/api/admin", require("./routes/adminRoutes"));
app.use("/api/admin-add-blog", require("./routes/BlogRoutes"));
app.use("/api/admin-add-faqs", require("./routes/FAQRoutes"));
app.use("/api/admin-add-media", require("./routes/MediaRoutes"));
// Subscription routes
app.use("/api/plan", require("./routes/PlanRoutes"));
app.use("/api/subscriptions", require("./routes/subscriptionRoutes"));
app.use("/api/contact-us", require("./routes/contactRoutes"));
// Invoice Routes
app.use("/api/invoices", require("./routes/invoiceRoutes"));

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
