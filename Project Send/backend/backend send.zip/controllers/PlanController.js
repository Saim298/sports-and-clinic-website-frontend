const Plan = require("../models/PlanModel"); // Assuming your Plan model file is named PlanModel.js

// Create a new plan
exports.createPlan = async (req, res) => {
  try {
    const {
      title,
      price,
      coupons,
      discount,
      subHeading,
      enhancedFeatures,
      exportBookmarks,
      personalizedNotifications,
      exclusiveContent,
      accessSchoolInfo,
      accessCampInfo,
      canLeaveReviews,
      renewsMonthly,
      adFreeViewing,
      support24_7,
      duration,
    } = req.body;

    const plan = new Plan({
      title,
      price,
      coupons,
      discount,
      subHeading,
      enhancedFeatures,
      exportBookmarks,
      personalizedNotifications,
      exclusiveContent,
      accessSchoolInfo,
      accessCampInfo,
      canLeaveReviews,
      renewsMonthly,
      adFreeViewing,
      support24_7,
      duration,
    });

    await plan.save();
    res.status(201).json(plan);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Get all plans
exports.getAllPlans = async (req, res) => {
  try {
    const plans = await Plan.find();
    res.status(200).json(plans);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Get a specific plan by ID
exports.getPlanById = async (req, res) => {
  try {
    const plan = await Plan.findById(req.params.id);
    if (!plan) {
      return res.status(404).json({ error: "Plan not found" });
    }
    res.status(200).json(plan);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Update a plan
// Update a plan
exports.updatePlan = async (req, res) => {
  try {
    const {
      title,
      price,
      coupons,
      discount,
      subHeading,
      enhancedFeatures,
      exportBookmarks,
      personalizedNotifications,
      exclusiveContent,
      accessSchoolInfo,
      accessCampInfo,
      canLeaveReviews,
      renewsMonthly,
      adFreeViewing,
      support24_7,
      duration,
    } = req.body;

    // Find the plan by ID and update the fields
    const plan = await Plan.findById(req.params.id);

    if (!plan) {
      return res.status(404).json({ error: "Plan not found" });
    }

    // Update the fields if they are provided
    if (title !== undefined) plan.title = title;
    if (price !== undefined) {
      if (price.monthly !== undefined) plan.price.monthly = price.monthly;
      if (price.yearly !== undefined) plan.price.yearly = price.yearly;
    }
    if (coupons !== undefined) plan.coupons = coupons;
    if (discount !== undefined) plan.discount = discount;
    if (subHeading !== undefined) plan.subHeading = subHeading;
    if (enhancedFeatures !== undefined) plan.enhancedFeatures = enhancedFeatures;
    if (exportBookmarks !== undefined) plan.exportBookmarks = exportBookmarks;
    if (personalizedNotifications !== undefined) plan.personalizedNotifications = personalizedNotifications;
    if (exclusiveContent !== undefined) plan.exclusiveContent = exclusiveContent;
    if (accessSchoolInfo !== undefined) plan.accessSchoolInfo = accessSchoolInfo;
    if (accessCampInfo !== undefined) plan.accessCampInfo = accessCampInfo;
    if (canLeaveReviews !== undefined) plan.canLeaveReviews = canLeaveReviews;
    if (renewsMonthly !== undefined) plan.renewsMonthly = renewsMonthly;
    if (adFreeViewing !== undefined) plan.adFreeViewing = adFreeViewing;
    if (support24_7 !== undefined) plan.support24_7 = support24_7;
    if (duration !== undefined) plan.duration = duration;

    // Automatically update the points array based on selected features
    plan.points = [];
    if (plan.enhancedFeatures) plan.points.push('Enhanced features');
    if (plan.exportBookmarks) plan.points.push('Export bookmarks into printable format');
    if (plan.personalizedNotifications) plan.points.push('Personalized notifications');
    if (plan.exclusiveContent) plan.points.push('Exclusive content');
    if (plan.accessSchoolInfo) plan.points.push('Access to school information');
    if (plan.accessCampInfo) plan.points.push('Access to all camp information');
    if (plan.canLeaveReviews) plan.points.push('Can leave reviews for camps');
    if (plan.renewsMonthly) plan.points.push('Renews monthly');
    if (plan.adFreeViewing) plan.points.push('Ad-free Viewing');
    if (plan.support24_7) plan.points.push('24/7 Support');

    // Save the updated plan
    await plan.save();

    res.status(200).json(plan);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


// Delete a plan
exports.deletePlan = async (req, res) => {
  try {
    const plan = await Plan.findByIdAndDelete(req.params.id);
    if (!plan) {
      return res.status(404).json({ error: "Plan not found" });
    }
    res.status(200).json({ message: "Plan deleted successfully" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
