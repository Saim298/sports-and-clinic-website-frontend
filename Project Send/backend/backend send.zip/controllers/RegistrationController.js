const Registration = require("../models/RegistrationModel");
const Event = require("../models/EventModel");
const RegistrationModel = require("../models/RegistrationModel");

// Register a user for an event
exports.registerForEvent = async (req, res) => {
  try {
    const { user, event, ageGroup, emergencyContact, specialRequirements } =
      req.body;

    const eventDetails = await Event.findById(event);
    if (!eventDetails) {
      return res.status(404).json({ error: "Event not found" });
    }

    const registration = new Registration({
      user,
      event,
      ageGroup,
      emergencyContact,
      specialRequirements,
      paymentStatus: "pending", // Default value, could be omitted as it defaults to 'pending'
    });

    await registration.save();
    res.status(201).json(registration);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Get all registrations for a user
exports.getUserRegistrations = async (req, res) => {
  try {
    const registrations = await RegistrationModel
    .find({ user: req.params.userId })
      .populate("event")
      .exec();
    res.status(200).json(registrations);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all registrations for an event
exports.getEventRegistrations = async (req, res) => {
  try {
    const registrations = await Registration.find({ event: req.params.eventId })
      .populate("user")
      .exec();
    res.status(200).json(registrations);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};




// Get registrants for a specific event by event ID
exports.getRegistrantsByEventId = async (req, res) => {
  try {
    const eventId = req.params.id;

    // Find registrations for the given event ID
    const registrations = await Registration.find({ event: eventId })
      .populate({
        path: 'user',
        select: '-password' // Exclude the password field from user details
      })
      .exec();

    if (!registrations || registrations.length === 0) {
      return res.status(404).json({ error: "No registrants found for this event" });
    }

    res.status(200).json(registrations);
  } catch (error) {
    console.error("Error fetching registrants:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};