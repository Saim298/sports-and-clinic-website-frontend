const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const paypal = require("@paypal/checkout-server-sdk");
const Plan = require("../models/PlanModel");
const Subscription = require("../models/SubscriptionModel");
const User = require("../models/User"); // Add this line to import User model
const moment = require("moment");

// PayPal client setup
const paypalClient = new paypal.core.PayPalHttpClient(
  new paypal.core.SandboxEnvironment(
    process.env.PAYPAL_CLIENT_ID,
    process.env.PAYPAL_CLIENT_SECRET
  )
);

const calculateAmount = async (plan, promoCode, duration) => {
  let discount = plan.discount;
  let planPrice;

  if (duration === "yearly") {
    planPrice = plan.price.yearly;
  } else {
    planPrice = plan.price.monthly;
  }

  if (promoCode && plan.coupons.includes(promoCode)) {
    discount += plan.discount;
  }

  const discountedPrice = planPrice - planPrice * (discount / 100);
  return Math.max(discountedPrice, 0);
};

exports.subscribeToPlan = async (req, res) => {
  const { userId, planId, promoCode, paymentMethod, duration } = req.body;

  try {
    const plan = await Plan.findById(planId);
    if (!plan) return res.status(404).json({ error: "Plan not found" });

    let amount = await calculateAmount(plan, promoCode, duration);
    amount = amount.toFixed(2);

    const subscription = new Subscription({
      user: userId,
      plan: plan.title,
      amount: parseFloat(amount),
      paymentMethod,
      paymentStatus: "pending",
      duration,
    });
    await subscription.save();

    if (paymentMethod === "stripe") {
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: `Subscription to ${plan.title} (${duration} plan)`,
              },
              unit_amount: Math.round(amount * 100),
            },
            quantity: 1,
          },
        ],
        mode: "payment",
        success_url: `${process.env.FRONTEND_URL}/subscription-success/{CHECKOUT_SESSION_ID}/${subscription._id}`,
        cancel_url: `${process.env.FRONTEND_URL}/subscription-cancelled`,
        metadata: {
          subscriptionId: subscription._id.toString(),
          userId: userId,
        },
      });

      // Update the user document with subscription details
      await User.findByIdAndUpdate(userId, {
        $push: { subscriptions: subscription._id },
      });

      res.json({ sessionId: session.id });
    } else if (paymentMethod === "paypal") {
      const request = new paypal.orders.OrdersCreateRequest();
      request.prefer("return=representation");
      request.requestBody({
        intent: "CAPTURE",
        purchase_units: [
          {
            amount: {
              currency_code: "USD",
              value: amount,
            },
            description: `Subscription to ${plan.title} (${duration} plan)`,
          },
        ],
        application_context: {
          return_url: `${process.env.FRONTEND_URL}/subscription-success/${subscription._id}`,
          cancel_url: `${process.env.FRONTEND_URL}/subscription-cancel`,
        },
      });

      const orderResult = await paypalClient.execute(request);

      subscription.paypalOrderId = orderResult.result.id;
      await subscription.save();

      // Update the user document with subscription details
      await User.findByIdAndUpdate(userId, {
        $push: { subscriptions: subscription._id },
      });

      res.json({
        approvalUrl: orderResult.result.links.find(
          (link) => link.rel === "approve"
        ).href,
      });
    } else {
      res.status(400).json({ error: "Invalid payment method" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Subscription processing failed" });
  }
};

// Function to handle payment confirmation and update subscription status
exports.updateSubscriptionStatus = async (req, res) => {
  const { subscriptionId, session_id } = req.body; // Extract subscriptionId and session_id from the request body

  try {
    const subscription = await Subscription.findById(subscriptionId);
    if (!subscription) throw new Error("Subscription not found");

    // Verify the session_id here if needed, depending on your payment processor's verification method
    // Assuming session_id is valid and payment is successful, we proceed to update the subscription status

    // Update payment status and subscription start date
    subscription.paymentStatus = "completed";
    subscription.status = true; // Update status from pending to completed (true)
    subscription.subscriptionStartDate = Date.now();

    await subscription.save();
    return res.status(200).json({
      message: "Subscription status updated successfully",
      subscription,
    });
  } catch (error) {
    console.error("Failed to update subscription status:", error);
    return res.status(500).json({
      message: "Failed to update subscription status",
      error: error.message,
    });
  }
};

exports.checkUserSubscription = async (req, res) => {
  const { userId } = req.body;

  try {
    // Find the subscription for the given user with completed payment status
    const subscription = await Subscription.findOne({
      user: userId,
      paymentStatus: "completed",
    });

    if (!subscription) {
      return res.status(200).json({
        subscribed: false,
        userId,
      });
    }

    // Ensure `now` and `subscriptionStartDate` are in UTC
    const now = moment.utc();
    const subscriptionStartDate = moment(
      subscription.subscriptionStartDate
    ).utc();

    const isSubscriptionExpired =
      (subscription.duration === "monthly" &&
        now.diff(subscriptionStartDate, "months") >= 1) ||
      (subscription.duration === "yearly" &&
        now.diff(subscriptionStartDate, "years") >= 1);

    if (isSubscriptionExpired) {
      return res.status(200).json({
        subscribed: false,
        userId,
      });
    }

    // Find the plan details using the title from the subscription
    const plan = await Plan.findOne({ title: subscription.plan });

    if (!plan) {
      return res.status(500).json({
        error: "Plan associated with subscription not found",
      });
    }

    res.status(200).json({
      subscribed: true,
      subscription: {
        _id: subscription._id,
        user: subscription.user,
        plan: subscription.plan,
        amount: subscription.amount,
        paymentStatus: subscription.paymentStatus,
        paymentMethod: subscription.paymentMethod,
        duration: subscription.duration,
        subscriptionStartDate: subscription.subscriptionStartDate,
        createdAt: subscription.createdAt,
        updatedAt: subscription.updatedAt,
      },
      plan: {
        title: plan.title,
        price: plan.price[subscription.duration], // Return price based on duration (monthly/yearly)
        coupons: plan.coupons,
        discount: plan.discount,
        subHeading: plan.subHeading,
        points: plan.points,
        enhancedFeatures: plan.enhancedFeatures,
        exportBookmarks: plan.exportBookmarks,
        personalizedNotifications: plan.personalizedNotifications,
        exclusiveContent: plan.exclusiveContent,
        accessSchoolInfo: plan.accessSchoolInfo,
        accessCampInfo: plan.accessCampInfo,
        canLeaveReviews: plan.canLeaveReviews,
        renewsMonthly: plan.renewsMonthly,
        adFreeViewing: plan.adFreeViewing,
        support24_7: plan.support24_7,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to check subscription status" });
  }
};

exports.generateInvoices = async (req, res) => {
  const { userId } = req.body;

  try {
    // Find the user and populate completed subscriptions
    const user = await User.findById(userId).populate({
      path: 'subscriptions',
      match: { paymentStatus: 'completed' },
      populate: { path: 'plan' }
    });

    // Debug logs to verify data
    console.log('User:', user);
    console.log('User Subscriptions:', user.subscriptions);

    if (!user || !user.subscriptions.length) {
      return res.status(404).json({ error: "No completed subscriptions found for this user" });
    }

    // Generate invoices for all subscriptions
    const invoices = user.subscriptions.map(subscription => {
      const plan = subscription.plan;

      return {
        user: {
          name: user.firstName + ' ' + user.lastName, // Use full name if available
          email: user.email,
          userId:user._id,
        },
        subscription: {
          plan: plan.title,
          duration: subscription.duration,
          amount: subscription.amount,
          startDate: subscription.subscriptionStartDate,
          paymentMethod: subscription.paymentMethod,
        },
        createdAt: new Date(),
      };
    });

    res.status(200).json({ invoices });
  } catch (error) {
    console.error("Failed to generate invoices:", error);
    res.status(500).json({ error: "Failed to generate invoices" });
  }
};

