// controllers/contactController.js
const Contact = require('../models/contactUsModel');

exports.createContact = async (req, res) => {
  try {
    const { firstName, lastName, email, hasSubscription, message } = req.body;
    
    const newContact = new Contact({
      firstName,
      lastName,
      email,
      hasSubscription,
      message,
    });

    await newContact.save();
    res.status(201).json({
      success: true,
      message: 'Contact information submitted successfully',
      data: newContact,
    });
  } catch (error) {
    console.error('Error creating contact:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit contact information',
      error: error.message,
    });
  }
};

exports.getContacts = async (req, res) => {
  try {
    const contacts = await Contact.find();
    res.status(200).json({
      success: true,
      data: contacts,
    });
  } catch (error) {
    console.error('Error fetching contacts:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch contacts',
      error: error.message,
    });
  }
};
