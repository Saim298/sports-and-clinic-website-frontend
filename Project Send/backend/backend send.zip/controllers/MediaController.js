const Media = require("../models/MediaModel");
const cloudinary = require("cloudinary").v2;

// Configure Cloudinary using environment variables
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});


// Create new media
// Create new media
exports.createMedia = async (req, res) => {
  try {
    const { main_page_main_text, main_page_para_text, footer_text } = req.body;
    let main_page_image = "";

    // Upload image to Cloudinary
    if (req.file) { // Change this line
      main_page_image = await new Promise((resolve, reject) => {
        cloudinary.uploader.upload_stream(
          {
            folder: "media",
            resource_type: "image",
          },
          (error, result) => {
            if (error) return reject(error);
            resolve(result.secure_url);
          }
        ).end(req.file.buffer); // Change this line
      });
    } else {
      return res.status(400).json({ error: "Main page image is required" });
    }

    const media = new Media({
      main_page_main_text,
      main_page_para_text,
      footer_text,
      main_page_image,
    });

    await media.save();
    res.status(201).json(media);
  } catch (error) {
    console.error("Error creating media:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};



// Update media
exports.updateMedia = async (req, res) => {
  try {
    const { id } = req.params;
    const { main_page_main_text, main_page_para_text, footer_text } = req.body;
    let main_page_image = "";

    // Check if a new image is provided
    if (req.file) {
      const result = await cloudinary.uploader.upload_stream(
        {
          folder: "media",
        },
        (error, result) => {
          if (error) {
            console.error("Error uploading to Cloudinary:", error);
            return res.status(500).json({ error: "Error uploading image" });
          }
          main_page_image = result.secure_url;
        }
      ).end(req.file.buffer); // Use the file buffer here
    } else {
      main_page_image = req.body.main_page_image;
    }

    const updatedMedia = await Media.findByIdAndUpdate(
      id,
      {
        main_page_main_text,
        main_page_para_text,
        footer_text,
        main_page_image,
        updatedAt: Date.now(),
      },
      { new: true }
    );

    if (!updatedMedia) {
      return res.status(404).json({ message: "Media not found" });
    }

    res.status(200).json({ message: "Media updated successfully", media: updatedMedia });
  } catch (error) {
    console.error("Error updating media:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};



// Get all media
exports.getAllMedia = async (req, res) => {
  try {
    const media = await Media.find();
    res.status(200).json(media);
  } catch (error) {
    console.error("Error fetching media:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// Get media by ID
exports.getMediaById = async (req, res) => {
  try {
    const { id } = req.params;
    const media = await Media.findById(id);
    if (!media) {
      return res.status(404).json({ message: "Media not found" });
    }
    res.status(200).json(media);
  } catch (error) {
    console.error("Error fetching media:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// Delete media
exports.deleteMedia = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedMedia = await Media.findByIdAndDelete(id);

    if (!deletedMedia) {
      return res.status(404).json({ message: "Media not found" });
    }

    res.status(200).json({ message: "Media deleted successfully" });
  } catch (error) {
    console.error("Error deleting media:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
