const cloudinary = require('cloudinary').v2;
const Blog = require('../models/BlogModel');

// Configure Cloudinary using environment variables
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Create a new blog
exports.createBlog = async (req, res) => {
  const { blogName, description, keywords, metaTags } = req.body;

  try {
    let blogImage = '';

    // Check if image is provided
    if (req.file) {
      // Upload image from memory using upload_stream
      const result = await new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(
          { folder: 'blogs/images' },
          (error, result) => {
            if (error) return reject(error);
            resolve(result);
          }
        );
        stream.end(req.file.buffer);
      });

      blogImage = result.secure_url;
    } else {
      return res.status(400).json({ error: 'Image is required' });
    }

    const newBlog = new Blog({
      blogName,
      blogImage,
      description,
      keywords,
      metaTags,
    });

    await newBlog.save();
    res.status(201).json(newBlog);
  } catch (error) {
    console.error('Error creating blog:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


// Get all blogs
exports.getBlogs = async (req, res) => {
  try {
    const blogs = await Blog.find();
    res.status(200).json(blogs);
  } catch (error) {
    console.error('Error fetching blogs:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get blog by ID
exports.getBlogById = async (req, res) => {
  const { id } = req.params;

  try {
    const blog = await Blog.findById(id);
    if (!blog) {
      return res.status(404).json({ error: 'Blog not found' });
    }
    res.status(200).json(blog);
  } catch (error) {
    console.error('Error fetching blog:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update blog by ID
exports.updateBlog = async (req, res) => {
  const { id } = req.params;
  const { blogName, description, keywords, metaTags } = req.body;

  try {
    let blogImage = '';

    if (req.file) {
      const result = await cloudinary.uploader.upload(req.file.path, {
        folder: 'blogs/images',
      });
      blogImage = result.secure_url;
    }

    const updatedBlog = await Blog.findByIdAndUpdate(
      id,
      {
        blogName,
        blogImage: blogImage || undefined,
        description,
        keywords,
        metaTags,
      },
      { new: true }
    );

    if (!updatedBlog) {
      return res.status(404).json({ error: 'Blog not found' });
    }

    res.status(200).json(updatedBlog);
  } catch (error) {
    console.error('Error updating blog:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Delete blog by ID
exports.deleteBlog = async (req, res) => {
  const { id } = req.params;

  try {
    const blog = await Blog.findByIdAndDelete(id);
    if (!blog) {
      return res.status(404).json({ error: 'Blog not found' });
    }
    res.status(200).json({ message: 'Blog deleted successfully' });
  } catch (error) {
    console.error('Error deleting blog:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


// Increment the view count of a specific blog
exports.incrementView = async (req, res) => {
  const { blogId } = req.params;

  try {
    const blog = await Blog.findById(blogId);
    if (!blog) {
      return res.status(404).json({ error: 'Blog not found' });
    }

    blog.views += 1;
    await blog.save();

    res.status(200).json({ message: 'View count incremented', views: blog.views });
  } catch (error) {
    console.error('Error incrementing view count:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Add a comment to a specific blog
exports.addComment = async (req, res) => {
  const { blogId } = req.params;
  const { userName, content } = req.body;

  try {
    const blog = await Blog.findById(blogId);
    if (!blog) {
      return res.status(404).json({ error: 'Blog not found' });
    }

    const newComment = {
      userName,
      content,
    };

    blog.comments.push(newComment);
    await blog.save();

    res.status(201).json({ message: 'Comment added', comments: blog.comments });
  } catch (error) {
    console.error('Error adding comment:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Reply to a specific comment in a blog
exports.replyToComment = async (req, res) => {
  const { blogId, commentId } = req.params;
  const { userName, content } = req.body;

  try {
    const blog = await Blog.findById(blogId);
    if (!blog) {
      return res.status(404).json({ error: 'Blog not found' });
    }

    const comment = blog.comments.id(commentId);
    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }

    const reply = {
      userName,
      content,
    };

    comment.replies.push(reply);
    await blog.save();

    res.status(201).json({ message: 'Reply added', replies: comment.replies });
  } catch (error) {
    console.error('Error adding reply:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
