const Invoice = require("../models/Invoice");
const User = require("../models/User"); // Assuming User model exists
const cloudinary = require("cloudinary").v2;

// Configure Cloudinary using environment variables
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});
// Save new invoice
exports.createInvoice = async (req, res) => {
  try {
    const { html } = req.body;
    console.log(html);

    // First, update all other invoices to set `isActive` to false
    await Invoice.updateMany({}, { $set: { isActive: false } });

    // Create a new invoice with `isActive` set to true
    const newInvoice = new Invoice({
      htmlContent: html,
      isActive: true, // Set the new invoice as active
    });

    // Save the new invoice to the database
    const savedInvoice = await newInvoice.save();

    return res.status(201).json({
      status: "success",
      data: savedInvoice,
    });
  } catch (error) {
    return res.status(500).json({
      status: "error",
      message: "Failed to save invoice",
      error: error.message,
    });
  }
};

// Image upload handler function
exports.uploadImage = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No image file provided" });
    }

    // Upload image to Cloudinary
    cloudinary.uploader
      .upload_stream(
        {
          resource_type: "image",
          folder: "uploads/images",
        },
        (error, result) => {
          if (error) {
            console.error("Error uploading to Cloudinary:", error);
            return res.status(500).json({ error: "Failed to upload image" });
          }

          // Respond with the Cloudinary URL
          return res.status(200).json({
            message: "Image uploaded successfully",
            url: result.secure_url,
          });
        }
      )
      .end(req.file.buffer); // Use multer's file buffer to upload
  } catch (error) {
    console.error("Error during image upload:", error.message);
    return res.status(500).json({ error: error.message });
  }
};

// Helper function to replace placeholders in HTML
const replacePlaceholders = (html, data) => {
  return html
    .replace(/{{name}}/g, data.user.name)
    .replace(/{{email}}/g, data.user.email)
    .replace(/{{plan}}/g, data.subscription.plan)
    .replace(/{{duration}}/g, data.subscription.duration)
    .replace(/{{amount}}/g, data.subscription.amount)
    .replace(/{{startDate}}/g, data.subscription.startDate)
    .replace(/{{paymentMethod}}/g, data.subscription.paymentMethod)
    .replace(/{{createdAt}}/g, data.createdAt);
};

// Save new invoice
exports.saveInvoice = async (req, res) => {
  try {
    const { userId } = req.params;

    // Find the user and their completed subscription
    const user = await User.findById(userId).populate({
      path: "subscriptions",
      match: { paymentStatus: "completed" },
      populate: { path: "plan" },
    });

    if (!user || !user.subscriptions.length) {
      return res
        .status(404)
        .json({ error: "No completed subscriptions found for this user" });
    }

    const subscription = user.subscriptions[0]; // Assuming you're generating invoice for the first subscription
    const invoiceData = {
      user: {
        name: `${user.firstName} ${user.lastName}`,
        email: user.email,
      },
      subscription: {
        plan: subscription.plan.title,
        duration: subscription.duration,
        amount: subscription.amount,
        startDate: subscription.subscriptionStartDate,
        paymentMethod: subscription.paymentMethod,
      },
      createdAt: new Date(),
    };

    // Retrieve the active invoice template from the database
    const activeInvoiceTemplate = await Invoice.findOne({ isActive: true });

    if (!activeInvoiceTemplate) {
      return res
        .status(404)
        .json({ error: "No active invoice template found" });
    }

    // Replace placeholders in the HTML template
    const processedHtml = replacePlaceholders(
      activeInvoiceTemplate.htmlContent,
      invoiceData
    );

    // Set all invoices to inactive before creating a new one
    await Invoice.updateMany({ isActive: true }, { isActive: false });

    // Create a new invoice document with the processed HTML content
    const newInvoice = new Invoice({
      htmlContent: processedHtml,
      isActive: true,
    });

    // Save the invoice
    const savedInvoice = await newInvoice.save();

    return res.status(201).json({
      status: "success",
      data: savedInvoice,
    });
  } catch (error) {
    return res.status(500).json({
      status: "error",
      message: "Failed to save invoice",
      error: error.message,
    });
  }
};

// Get active invoice
exports.getActiveInvoice = async (req, res) => {
  try {
    // Fetch the active invoice from the database
    const activeInvoice = await Invoice.findOne({ isActive: true });

    if (!activeInvoice) {
      return res.status(404).json({ error: "No active invoice found" });
    }

    return res.status(200).json({
      status: "success",
      data: activeInvoice,
    });
  } catch (error) {
    return res.status(500).json({
      status: "error",
      message: "Failed to fetch active invoice",
      error: error.message,
    });
  }
};

// Update invoice
exports.updateInvoice = async (req, res) => {
  try {
    const { invoiceId, html, isActive } = req.body;

    // Find and update the invoice
    const updatedInvoice = await Invoice.findByIdAndUpdate(
      invoiceId,
      { htmlContent: html, isActive },
      { new: true }
    );

    if (!updatedInvoice) {
      return res.status(404).json({ error: "Invoice not found" });
    }

    // Optionally, deactivate other invoices if this one is active
    if (isActive) {
      await Invoice.updateMany(
        { _id: { $ne: invoiceId } },
        { isActive: false }
      );
    }

    return res.status(200).json({
      status: "success",
      data: updatedInvoice,
    });
  } catch (error) {
    return res.status(500).json({
      status: "error",
      message: "Failed to update invoice",
      error: error.message,
    });
  }
};
