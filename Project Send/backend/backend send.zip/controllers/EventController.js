const cloudinary = require("cloudinary").v2;
const Event = require("../models/EventModel"); // Assuming you have an Event model
const User = require("../models/User");

// Configure Cloudinary using environment variables
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Create a new event

// Create a new event
exports.createEvent = async (req, res) => {
  const {
    title,
    description,
    date,
    time,
    location,
    coachProfiles,
    reviews,
    ageGroups,
    category,
    recurring,
    isActive,
    briefCampIntro,
    athleticsInfo,
    socialNetworks,
    recruitingQuestionnaire,
    tags,
    endDate,
    campWebsiteLink,
  } = req.body;

  console.log(req.body);

  try {
    // Parse JSON strings into objects if they exist
    const parsedCoachProfiles = coachProfiles ? JSON.parse(coachProfiles) : [];
    const parsedReviews = reviews ? JSON.parse(reviews) : [];
    const parsedAgeGroups = ageGroups ? JSON.parse(ageGroups) : [];
    const parsedTags = tags ? JSON.parse(tags) : [];
    const parsedSocialNetworks = socialNetworks ? JSON.parse(socialNetworks) : {};
    const parsedAthleticsInfo = athleticsInfo ? JSON.parse(athleticsInfo) : {};
    const parsedRecruitingQuestionnaire =
      recruitingQuestionnaire && recruitingQuestionnaire !== 'undefined'
        ? JSON.parse(recruitingQuestionnaire)
        : "";

    // Validate and parse location
    const locationObj = location ? JSON.parse(location) : {};
    const parsedLocation = {
      type: "Point",
      coordinates: locationObj.coordinates || [0, 0], // Default to [0,0] if not provided
      address: locationObj.address || "",
    };

    // Initialize media object for images and videos
    let media = { images: [], videos: [] };

    // Handle image uploads to Cloudinary
    if (req.files.images) {
      const imageUploads = req.files.images.map((image) => {
        return new Promise((resolve, reject) => {
          cloudinary.uploader.upload_stream(
            {
              resource_type: "image",
              folder: "events/images",
            },
            (error, result) => {
              if (error) return reject(error);
              resolve(result.secure_url);
            }
          ).end(image.buffer);
        });
      });
      media.images = await Promise.all(imageUploads);
    } else {
      return res.status(400).json({ error: "Images are required" });
    }

    // Handle video uploads to Cloudinary
    if (req.files.videos) {
      const videoUploads = req.files.videos.map((video) => {
        return new Promise((resolve, reject) => {
          cloudinary.uploader.upload_stream(
            {
              resource_type: "video",
              folder: "events/videos",
            },
            (error, result) => {
              if (error) return reject(error);
              resolve(result.secure_url);
            }
          ).end(video.buffer);
        });
      });
      media.videos = await Promise.all(videoUploads);
    }

    // Handle recurring event fields
    let parsedRecurring = {
      isRecurring: false,
      recurrenceRule: null,
      endDate: null,
    };

    if (recurring) {
      const recurringParsed = JSON.parse(recurring);
      parsedRecurring.isRecurring = recurringParsed.isRecurring;
      parsedRecurring.recurrenceRule = recurringParsed.recurrenceRule || null;

      // Check if endDate is valid
      if (recurringParsed.endDate) {
        const endDateParsed = new Date(recurringParsed.endDate);
        if (!isNaN(endDateParsed.getTime())) {
          parsedRecurring.endDate = endDateParsed;
        } else {
          throw new Error("Invalid end date provided for recurring event.");
        }
      }
    }

    // Create new event document
    const event = new Event({
      title,
      description,
      date,
      time,
      location: parsedLocation,
      coachProfiles: parsedCoachProfiles,
      reviews: parsedReviews,
      ageGroups: parsedAgeGroups,
      media,  // Attach media (images and videos)
      category,
      recurring: parsedRecurring,
      isActive,
      briefCampIntro,
      athleticsInfo: parsedAthleticsInfo,
      socialNetworks: parsedSocialNetworks,
      recruitingQuestionnaire: parsedRecruitingQuestionnaire,
      tags: parsedTags,
      endDate: endDate ? new Date(endDate) : null,
      campWebsiteLink,  // Added campWebsiteLink field
    });

    // Save event to the database
    await event.save();
    return res.status(201).json(event);

  } catch (error) {
    console.error("Error creating event:", error.message);
    return res.status(400).json({ error: error.message });
  }
};



// Add a review to an event
exports.addEventReview = async (req, res) => {
  const { eventId, userId, review, rating } = req.body;

  try {
    // Find the event by ID
    const event = await Event.findById(eventId);
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }

    // Check if the user has already reviewed the event
    const existingReview = event.reviews.find(
      (r) => r.user.toString() === userId
    );

    if (existingReview) {
      return res
        .status(400)
        .json({ error: "You have already reviewed this event" });
    }

    // Add the new review to the event's reviews array
    const newReview = {
      user: userId,
      review,
      rating,
    };

    event.reviews.push(newReview);

    // Save the event with the new review
    await event.save();

    res.status(201).json({ message: "Review added successfully", event });
  } catch (error) {
    console.error("Error adding review:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// Get event plan by ID
// Get event plan by ID
exports.getEventPlanById = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id).select(
      "paymentPlans price"
    ); // Fetch paymentPlans and price fields
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }
    res.status(200).json({
      paymentPlans: event.paymentPlans,
      price: event.price,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get the latest 3 events
exports.getLatestEvents = async (req, res) => {
  try {
    const events = await Event.find({})
      .sort({ date: -1 }) // Sort by date in descending order
      .limit(3); // Limit the number of events to 3
    res.status(200).json(events);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get all events
exports.getAllEvents = async (req, res) => {
  try {
    // Query to find all events without any date filtering
    const events = await Event.find({});

    res.status(200).json(events);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};




// Get event by ID

exports.getEventById = async (req, res) => {
  try {
    const eventId = req.params.id;
    const event = await Event.findById(eventId).lean().exec();

    // Populate reviews with user details
    const reviewsWithUserDetails = await Promise.all(
      event.reviews.map(async (review) => {
        const user = await User.findById(review.user)
          .select("firstName lastName")
          .lean()
          .exec();
        return {
          ...review,
          userName: `${user.firstName} ${user.lastName}`,
        };
      })
    );

    // Attach reviews with user details to the event
    event.reviews = reviewsWithUserDetails;

    res.status(200).json(event);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
};

// Update an event
exports.updateEvent = async (req, res) => {
  try {
    const event = await Event.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }
    res.status(200).json(event);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Delete an event
exports.deleteEvent = async (req, res) => {
  try {
    const event = await Event.findByIdAndDelete(req.params.id);
    if (!event) {
      return res.status(404).json({ error: "Event not found" });
    }
    res.status(200).json({ message: "Event deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.bookmarkEvent = async (req, res) => {
  const { eventId, userId } = req.body;

  try {
    // Find the user by ID
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Check if the event is already bookmarked
    if (user.bookmarkedEvents.includes(eventId)) {
      return res.status(400).json({ error: "Event already bookmarked" });
    }

    // Add the event to the user's bookmarkedEvents array
    user.bookmarkedEvents.push(eventId);

    // Save the updated user document
    await user.save();

    res.status(200).json({ message: "Event bookmarked successfully" });
  } catch (error) {
    console.error("Error bookmarking event:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};


exports.getBookmarkedEvents = async (req, res) => {
  const { userId } = req.params;

  try {
    // Find the user and populate the bookmarkedEvents field
    const user = await User.findById(userId).populate("bookmarkedEvents");
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    res.status(200).json(user.bookmarkedEvents);
  } catch (error) {
    console.error("Error retrieving bookmarked events:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};


// Get all registered events// Function to get all events
// Get all registered events with full details
exports.getAllRegisteredEvents = async (req, res) => {
  try {
    const events = await Event.find()
      .sort({ date: 1 }) // Sort by date in ascending order
      .select(
        "title description date time endDate location briefCampIntro athleticsInfo campWebsiteLink socialNetworks tags category coachProfiles reviews ageGroups media discount promoCodes recurring isActive"
      )
      .lean()
      .exec();

    res.status(200).json(events);
  } catch (error) {
    console.error("Error fetching all registered events:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};


