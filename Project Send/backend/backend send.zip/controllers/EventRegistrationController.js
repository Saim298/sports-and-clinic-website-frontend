const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const paypal = require("@paypal/checkout-server-sdk");
const Event = require("../models/EventModel");
const Order = require("../models/OrderModel");

// PayPal client setup
const paypalClient = new paypal.core.PayPalHttpClient(
  new paypal.core.SandboxEnvironment(
    process.env.PAYPAL_CLIENT_ID,
    process.env.PAYPAL_CLIENT_SECRET
  )
);

// Calculate the final amount considering discount, promo code, etc.
const calculateAmount = async (event, promoCode) => {
  let discount = event.discount;

  if (promoCode) {
    const promo = event.promoCodes.find(
      (p) => p.code === promoCode && p.validUntil > Date.now()
    );
    if (promo) discount += promo.discount;
  }

  const discountedPrice = event.price - event.price * (discount / 100);
  return Math.max(discountedPrice, 0); // Ensure non-negative price
};

exports.registerForEvent = async (req, res) => {
  const { userId, eventId, promoCode, paymentPlan, paymentMethod } = req.body;

  try {
    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ error: "Event not found" });

    let amount = await calculateAmount(event, promoCode);
    if (paymentPlan) {
      const plan = event.paymentPlans.find((p) => p.name === paymentPlan);
      if (plan) {
        const interest = amount * (plan.interestRate / 100);
        amount += interest;
      } else {
        return res.status(400).json({ error: "Invalid payment plan" });
      }
    }

    // Create a new order and save it with a pending payment status
    const order = new Order({
      user: userId,
      event: eventId,
      amount,
      paymentMethod,
      paymentStatus: "pending",
      promoCode,
    });
    await order.save();

    if (paymentMethod === "stripe") {
      // Stripe Payment Processing
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: {
                name: `Event Registration for ${event.title}`,
              },
              unit_amount: Math.round(amount * 100), // Stripe expects the amount in cents
            },
            quantity: 1,
          },
        ],
        mode: "payment",
        success_url: `${process.env.FRONTEND_URL}/payment-success/{CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.FRONTEND_URL}/payment-cancelled`,
        metadata: {
          orderId: order._id.toString(),
          userId: userId,
        },
      });

      // Return the session ID for redirection
    res.json({ sessionId: session.id });
    } else if (paymentMethod === "paypal") {
      // PayPal Payment Processing
      const request = new paypal.orders.OrdersCreateRequest();
      request.prefer("return=representation");
      request.requestBody({
        intent: "CAPTURE",
        purchase_units: [
          {
            amount: {
              currency_code: "USD",
              value: amount.toFixed(2),
            },
            description: event.name,
          },
        ],
        application_context: {
          return_url: `${process.env.FRONTEND_URL}/payment-success/${order._id}`,
          cancel_url: `${process.env.FRONTEND_URL}/payment-cancel`,
        },
      });

      const orderResult = await paypalClient.execute(request);

      // Save the PayPal order ID to your database (if needed)
      order.paypalOrderId = orderResult.result.id;
      await order.save();

      // Redirect the user to the PayPal payment page
      res.redirect(orderResult.result.links.find(link => link.rel === 'approve').href);
    } else {
      res.status(400).json({ error: "Invalid payment method" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Payment processing failed" });
  }
};

exports.confirmPayment = async (req, res) => {
  const { userId, eventId, paymentMethod } = req.body;

  try {
    // Find the order based on userId, eventId, and paymentMethod
    const order = await Order.findOne({
      user: userId,
      event: eventId,
      paymentMethod,
    }); 

    if (!order) return res.status(404).json({ error: "Order not found" });

    if (order.paymentStatus === "completed") {
      return res.status(200).json({ message: "Payment already confirmed" });
    }

    // Skip payment confirmation and mark as completed
    order.paymentStatus = "completed";
    await order.save();

    // Update the payment status in the Registration collection
    const registration = await Registration.findOne({
      user: userId,
      event: eventId,
    });

    if (registration) {
      registration.paymentStatus = "completed";
      await registration.save();
    }

    return res
      .status(200)
      .json({ message: "Payment confirmed and registration updated" });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to confirm payment" });
  }
};


exports.getUserOrders = async (req, res) => {
  const { userId } = req.params;

  try {
    // Find orders based on the userId
    const orders = await Order.find({ user: userId })
      .populate('user', 'firstName lastName')  // Populate user details (e.g., firstName, lastName)
      .populate('event', 'title')  // Populate event details (e.g., title)
      .sort({ createdAt: -1 });    // Sort orders by creation date (most recent first)

    if (!orders || orders.length === 0) {
      return res.status(404).json({ error: "No orders found for this user" });
    }

    res.status(200).json({ orders });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to retrieve orders" });
  }
};

